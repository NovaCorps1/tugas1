#include <iostream>
using namespace std;

void konversi_rupiah(int jml_usdollar, int jml_euro, 
					double &konv_usdollar, double &konv_euro)
{
	konv_usdollar = jml_usdollar * 14359.45;
	konv_euro = jml_euro * 17486.79;
}

int main(){
	int jml_usdollar = 10;
	int jml_euro = 5;
	double konv_usdollar;
	double konv_euro;
	
	konversi_rupiah(jml_usdollar, jml_euro, konv_usdollar, konv_euro);
	
	cout << jml_usdollar << " USD sama dengan " << konv_usdollar << " rupiah." << endl;
	cout << jml_euro << " Euro sama dengan " << konv_euro << " rupiah." << endl;
	
	return 0;
}
