#include <iostream>
using namespace std;

void konversi_rupiah(int jml_usdollar, int jml_euro, 
					double *ptr_usdollar, double *ptr_euro)
{
	*ptr_usdollar = jml_usdollar * 14359.45;
	*ptr_euro = jml_euro * 17486.79;
}

int main(){
	int jml_usdollar = 10;
	int jml_euro = 5;
	double konv_usdollar;
	double konv_euro;
	double *ptr_konv_usdollar = &konv_usdollar;
	double *ptr_konv_euro = &konv_euro;
	
	konversi_rupiah(jml_usdollar, jml_euro, ptr_konv_usdollar, ptr_konv_euro);
	
	cout << jml_usdollar << " USD sama dengan " << *ptr_konv_usdollar << " rupiah." << endl;
	cout << jml_usdollar << " USD sama dengan " << konv_usdollar << " rupiah." << endl;
	cout << jml_euro << " Euro sama dengan " << *ptr_konv_euro << " rupiah." << endl;
	
	return 0;
}
