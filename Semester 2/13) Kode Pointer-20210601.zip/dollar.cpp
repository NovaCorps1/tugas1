#include <iostream>
using namespace std;

double konversi_rupiah(int jml_usdollar)
{
	double hasil_konversi = jml_usdollar * 14359.45;
	
	return hasil_konversi;
}

int main(){
	int jml_usdollar = 2;
	double konv_usdollar;
	
	konv_usdollar = konversi_rupiah(jml_usdollar);
	
	cout << jml_usdollar << " USD sama dengan " << konv_usdollar << " rupiah." << endl;
	
	return 0;
}
