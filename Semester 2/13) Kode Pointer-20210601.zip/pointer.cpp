#include <iostream>
using namespace std;

int main(){
	int some_number = 25;
	int *pointer;
	pointer = &some_number;
	
	cout << "The value of some_number: " << some_number << endl;
	cout << "The address of some_number: " << &some_number << endl;
	cout << "The value of pointer: " << pointer << endl;
	cout << "The value of *pointer: " << *pointer << endl;
	cout << "The address of pointer: " << &pointer << endl;
	
	return 0;
}
